# PayerGuard — MVP Context Document

Status: Planning / pre-implementation
Last updated: 2026-08-18
Owner: AAT2

This document is the single source of truth for the PayerGuard MVP. Any human or AI agent picking up this project should be able to read this file top to bottom and understand what the project is, what data it uses, what the target architecture is, what is explicitly in and out of scope for the MVP, and the order in which work should be done. No implementation has started yet — this file, the repo skeleton, and the Docker setup are the only artifacts that exist so far. Everything downstream (backend logic, ML training, LLM integration, frontend) is future work to be picked up from here, most likely via spec-driven development (speckit) in a separate coding session/agent.

---

## 1. What is PayerGuard (project context)

PayerGuard is a claims quality and risk monitoring system for healthcare claims data. It takes raw insurance claims (initially CMS Medicare inpatient claims), runs them through a pipeline that:

1. Validates data quality deterministically (Great Expectations).
2. Detects statistical/behavioral anomalies in claim volume, amounts, and data quality using benchmarked anomaly-detection models.
3. Scores operational/SLA risk using benchmarked supervised ML models.
4. Escalates high-risk findings into structured "incidents."
5. Uses an LLM (Mistral) to investigate each incident and produce a root-cause explanation, evidence summary, business impact assessment, and a recommended (not auto-executed) fix.
6. Puts a human in the loop to accept or reject the LLM's recommendation.
7. On acceptance, runs a constrained, deterministic remediation engine against only the affected claims, then re-validates and shows before/after quality, anomaly, and risk scores.
8. Maintains full audit history of every decision (deterministic check, model score, LLM recommendation, human decision, remediation, revalidation).

The system is built to demonstrate a defensible, empirically-driven ML story: every model choice (which anomaly detector, which risk classifier) is the result of a benchmark on this project's actual data, not an assumption made in advance. Nothing in the pipeline should use fabricated/static placeholder values — all thresholds, baselines, and scores are computed from the real dataset.

### Why this matters / the narrative
"We benchmarked HBOS vs Isolation Forest vs LOF vs an IQR baseline for anomaly detection, and Logistic Regression vs Random Forest vs XGBoost for SLA-risk prediction, and selected the production model based on validation performance on our own data — not because a model 'sounds good.'"

---

## 2. Dataset

### 2.1 Source
CMS Medicare **Inpatient Claims** Research Identifiable File (RIF) format — a single file, `inpatient.csv`, supplied manually by the user. This is the **only** dataset used for the MVP. There is no second dataset, no live external feed, and no additional CMS file (outpatient, carrier, etc.) in scope right now.

The file is **pipe-delimited** (`|`), not comma-delimited, despite the `.csv` extension. Any ingestion code must use `sep="|"`.

### 2.2 Real, measured profile (from the actual file supplied)
These numbers were computed directly from `inpatient.csv` and must be treated as ground truth for baseline calculations — do not substitute assumed/synthetic numbers.

- **Rows (line-item grain):** 58,066 data rows, 197 columns.
- **Grain:** the file is at the **claim-line level**, not the claim level. Each row is one revenue-center line (`CLM_LINE_NUM`, `REV_CNTR`, `HCPCS_CD`) belonging to a claim.
- **Unique claims (`CLM_ID`):** 20,867.
- **Unique beneficiaries (`BENE_ID`):** 5,699.
- **Lines per claim:** mean 2.82, median 1, max 46 (heavily right-skewed — most claims have 1 line, a long tail has many).
- **Duplicate full rows:** 0.
- **Date range:** `CLM_FROM_DT` / `CLM_THRU_DT` / `CLM_ADMSN_DT` / `NCH_BENE_DSCHRG_DT` span **01-Apr-2015 to 31-Oct-2022**. Dates are stored as strings like `01-Apr-2015` (`DD-Mon-YYYY`), not ISO format — needs explicit parsing during standardization.
- **`CLM_PMT_AMT` (claim payment amount):** mean $13,638.31, median $1,481.72, std $35,993.91, min $62.44, max $598,716.31. Heavily right-skewed — use median/percentiles, not mean, for baselines.
- **`CLM_TOT_CHRG_AMT` (total charge amount):** identical distribution to `CLM_PMT_AMT` in this extract.
- **`PTNT_DSCHRG_STUS_CD`:** constant (100% = code `1`, "discharged home") in this extract — not usable as a variance signal, but still validated for schema conformance.
- **`CLM_DRG_CD` (diagnosis-related group):** 167 distinct values, ~5.5% missing.
- **`PRVDR_NUM` (provider number):** 4,876 distinct values, ~4.4% missing.
- **`CLM_IP_ADMSN_TYPE_CD`:** 3 categories — 1 (emergency, 43,089 rows), 3 (elective, 14,020 rows), 2 (urgent, 957 rows).
- **`PRVDR_STATE_CD`:** 51 distinct values (all US states + DC), reasonably spread.
- **`NCH_CLM_TYPE_CD`, `CLM_FREQ_CD`, `CLAIM_QUERY_CODE`, `CLM_MDCR_NON_PMT_RSN_CD`:** constant across the whole file — these are candidates for removal in Feature Selection Stage 1 (constant columns).
- **Fully-null columns (100% missing):** `OT_PHYSN_UPIN`, `OT_PHYSN_NPI`, `FI_CLM_ACTN_CD`, `FI_NUM`, `FI_CLM_PROC_DT`, `NCH_VRFD_NCVRD_STAY_FROM_DT`, `NCH_VRFD_NCVRD_STAY_THRU_DT`, `NCH_BENE_MDCR_BNFTS_EXHTD_DT_I`, `NCH_ACTV_OR_CVRD_LVL_CARE_THRU`, `CLM_UNCOMPD_CARE_PMT_AMT` — drop these outright.
- **Procedure code columns (`ICD_PRCDR_CD1`…`ICD_PRCDR_CD25` and paired `PRCDR_DTn`):** missingness increases sharply with position — `ICD_PRCDR_CD16` is already 98.3% missing, `ICD_PRCDR_CD25` is 99.9% missing. Only the first several procedure-code slots are usably populated; treat the rest as sparse/optional.
- **`ADMTG_DGNS_CD` (admitting diagnosis):** 72.2% missing. `PRNCPAL_DGNS_CD` (principal diagnosis): 0% missing — this is the more reliable diagnosis field.
- **`AT_PHYSN_NPI`, `ORG_NPI_NUM`:** 0% missing — reliable identifier fields.
- **`HCPCS_CD`:** 106 distinct procedure/service codes. **`REV_CNTR`:** only 2 distinct revenue-center codes in this extract.
- **`CLM_UTLZTN_DAY_CNT`:** mean 1.70, median 0, max 104 — utilization-day counts, mostly 0–1 with a long tail (long inpatient stays).

### 2.3 Column categories (only columns that actually exist in this file — no invented columns)

**Identifiers:** `BENE_ID`, `CLM_ID`, `PRVDR_NUM`, `ORG_NPI_NUM`, `AT_PHYSN_NPI`, `OP_PHYSN_NPI`, `FI_NUM`

**Dates:** `CLM_FROM_DT`, `CLM_THRU_DT`, `NCH_WKLY_PROC_DT`, `FI_CLM_PROC_DT`, `CLM_ADMSN_DT`, `NCH_BENE_DSCHRG_DT`, plus 25 paired `PRCDR_DTn` procedure dates

**Amounts (numerical):** `CLM_PMT_AMT`, `NCH_PRMRY_PYR_CLM_PD_AMT`, `CLM_TOT_CHRG_AMT`, `CLM_PASS_THRU_PER_DIEM_AMT`, `NCH_BENE_IP_DDCTBL_AMT`, `NCH_BENE_PTA_COINSRNC_LBLTY_AM`, `NCH_BENE_BLOOD_DDCTBL_LBLTY_AM`, `NCH_PROFNL_CMPNT_CHRG_AMT`, `NCH_IP_NCVRD_CHRG_AMT`, `NCH_IP_TOT_DDCTN_AMT`, and the `CLM_TOT_PPS_CPTL_*` / `CLM_PPS_CPTL_*` family (capital payment components)

**Utilization / duration (numerical):** `CLM_UTLZTN_DAY_CNT`, `BENE_TOT_COINSRNC_DAYS_CNT`, `BENE_LRD_USED_CNT`, `CLM_NON_UTLZTN_DAYS_CNT`, `NCH_BLOOD_PNTS_FRNSHD_QTY`

**Categorical / codes:** `NCH_NEAR_LINE_REC_IDENT_CD`, `NCH_CLM_TYPE_CD`, `CLAIM_QUERY_CODE`, `CLM_FAC_TYPE_CD`, `CLM_SRVC_CLSFCTN_TYPE_CD`, `CLM_FREQ_CD`, `CLM_MDCR_NON_PMT_RSN_CD`, `NCH_PRMRY_PYR_CD`, `PRVDR_STATE_CD`, `PTNT_DSCHRG_STUS_CD`, `CLM_PPS_IND_CD`, `CLM_IP_ADMSN_TYPE_CD`, `CLM_SRC_IP_ADMSN_CD`, `NCH_PTNT_STATUS_IND_CD`, `CLM_DRG_CD`, `CLM_DRG_OUTLIER_STAY_CD`, `HCPCS_CD`, `REV_CNTR`, `CLM_LINE_NUM`

**Diagnosis / procedure codes (high-cardinality, sparse):** `ADMTG_DGNS_CD`, `PRNCPAL_DGNS_CD`, `ICD_DGNS_CD1`…`ICD_DGNS_CD25` (+ `CLM_POA_IND_SWn` present-on-admission flags), `ICD_DGNS_E_CD1`…`ICD_DGNS_E_CD12`, `ICD_PRCDR_CD1`…`ICD_PRCDR_CD25`

**Candidate targets / labels:** there is no pre-existing SLA-breach or fraud label in this file. The MVP must **derive** an SLA-breach / risk label from operational proxies (e.g. processing delay between `CLM_FROM_DT`/`CLM_THRU_DT`/`FI_CLM_PROC_DT`/`NCH_WKLY_PROC_DT`, claim-line volume anomalies, quality-check failures) rather than assuming a label exists. This derivation logic must be defined and documented explicitly before Phase 8 (Risk Model Dataset), and validated against domain-reasonable thresholds — not invented arbitrarily.

Columns not listed above but present in the file (there are 197 total) should be profiled and categorized the same way as part of Phase 1/2 — this section covers the columns already confirmed relevant; the full column catalog belongs in the generated data-profiling report, not duplicated here.

---

## 3. Proposed architecture (data engineering → cloud deployment)

```
inpatient.csv (manual upload, pipe-delimited)
        │
        ▼
INGESTION SERVICE  (manual upload + continuous/batch file watch — NOT a live socket stream)
        │
        ▼
DATA ENGINEERING
  Schema validation → dtype conversion → missing-value handling →
  duplicate detection → invalid-value detection → date standardization
        │
        ▼
GREAT EXPECTATIONS (deterministic quality layer) ──► Quality Score (0–100)
        │
        ▼
HISTORICAL BASELINE  (mean/median/std/percentiles per metric, computed from clean historical claims)
        │
        ▼
FEATURE ENGINEERING
  Claim-level features  +  Window-level features (5/15/30-min or N-claim batches)
        │
        ▼
FEATURE SELECTION  (remove useless → statistical filter → model-based selection)
        │
        ├──────────────► ANOMALY DETECTION (benchmarked: IQR baseline, HBOS, Isolation Forest, LOF)
        │                        │
        │                        ▼
        │                  Selected production anomaly model + Anomaly Score (0–1)
        │
        ▼
RISK DATASET (incident/window-level rows: GX failures, anomaly score, volume deviation,
              processing delay, historical SLA rate, claim count, derived SLA-breach label)
        │
        ▼
RISK MODEL BENCHMARK (Logistic Regression, Random Forest, XGBoost — temporal train/val/test split)
        │
        ▼
Selected production risk model + SLA Risk Score (0–100)
        │
        ▼
RISK SCORING  (Quality + Anomaly + Operational + Risk → Final Incident Priority)
        │
        ▼
INCIDENT CREATION
        │
        ▼
LLM INVESTIGATION (Mistral)  → root cause, evidence, business impact, recommended fix
        │
        ▼
HUMAN-IN-THE-LOOP
  Accept → Remediation Engine (affected claims only) → Revalidate (GX + anomaly + risk) → Before/After
  Reject → Feedback → Recalculate → Human reviews again
        │
        ▼
AUDIT LOG (every step: check, score, LLM output, human decision, remediation, revalidation result)
```

### Backend architecture (modular, not a monolith)
Backend is a single deployable service for the MVP, but the codebase is split into one module per feature/domain (own files, own router, own service, own tests) rather than one large file. Target module boundaries:

`ingestion` · `data_engineering` (profiling/cleaning/standardization) · `quality` (Great Expectations) · `baseline` · `features` (claim-level, window-level, selection) · `anomaly` (iqr, hbos, isolation_forest, lof, benchmark) · `risk` (logistic, random_forest, xgboost, benchmark, scoring) · `llm` (Mistral client, prompts, investigation service) · `incidents` · `hitl` (accept/reject) · `remediation` (duplicate/missing/invalid-status/manual handlers) · `revalidation` · `simulation` (window batching over uploaded/continuously-ingested files — not a live stream) · `audit`

Each module owns its own database models, Pydantic schemas, service logic, and API router; `app/main.py` only wires routers together.

### Database (core tables — same as full plan)
`claims`, `claim_batches`, `baseline_metrics`, `quality_results`, `anomaly_results`, `features`, `risk_predictions`, `incidents`, `llm_investigations`, `human_feedback`, `remediations`, `revalidation_results`, `stream_windows` (repurposed as ingestion/processing windows, not live-stream windows), `audit_logs`.

### Cloud target (post-MVP, not built yet)
CloudFront → ALB → ECS/Fargate running two containers (frontend, backend) → RDS PostgreSQL + S3 (claims/models/logs) → ECR (both images) → CloudWatch (monitoring) → managed secrets store for `MISTRAL_API_KEY` / `DATABASE_URL`. The frontend is containerized the same way as the backend (its own Dockerfile, its own image in ECR) rather than shipped as a static S3/CloudFront bundle — this keeps local dev (`docker compose up`) and cloud deployment using the same container image. This is documented for planning purposes only; no cloud resources are provisioned as part of the MVP.

---

## 4. What is included in this MVP (and what is explicitly deferred)

**In scope:**
- Single dataset: `inpatient.csv` (CMS inpatient claims, pipe-delimited), ingested via manual upload.
- Continuous/repeated file ingestion (the user or a script can keep dropping/uploading batches over time), processed as discrete batches — **not** a live streaming API or claims simulator.
- Full data engineering pipeline: profiling, cleaning, standardization, keeping `original_value` / `cleaned_value` / `quality_issue` alongside cleaned data (never silently delete bad records).
- Great Expectations deterministic quality layer with a real, computed 0–100 quality score.
- Historical baseline computed from real cleaned data (no static/assumed baseline numbers).
- Claim-level and window-level feature engineering, three-stage feature selection.
- Anomaly detection benchmark: IQR baseline vs HBOS vs Isolation Forest vs LOF, with synthetic anomaly injection for evaluation (since there's no ground-truth label), scored on precision/recall/F1/FPR/latency/runtime. Production model selected empirically.
- Risk dataset built at incident/window grain with a derived (documented, non-arbitrary) SLA-breach label, temporal train/val/test split.
- Risk model benchmark: Logistic Regression vs Random Forest vs XGBoost, evaluated primarily on recall + PR-AUC (false negatives are the costly error), production model selected empirically.
- Composite risk scoring (Quality + Anomaly + Operational + Risk → priority).
- LLM investigation using **Mistral** (not Gemini) — root cause, evidence, impact, recommendation only; the LLM never executes fixes or touches the database directly.
- Human-in-the-loop accept/reject flow, feedback capture for future retraining.
- Constrained remediation engine (duplicate flagging, approved imputations, approved status mappings only; anything else becomes "Manual Action Required").
- Revalidation with before/after comparison.
- Full audit trail across the whole pipeline.
- Backend built as modular Python service, containerized with Docker/Docker Compose (backend + Postgres) for local development.
- Repo structure and Docker/dev environment scaffolding (this session's deliverable).
- Frontend, once built, will also ship as its own Docker container (own Dockerfile, added as a service in `docker-compose.yml`) rather than a separately-hosted static bundle — confirmed by the user, scaffolded as a placeholder now, wired up for real once frontend implementation starts.

**Explicitly deferred / out of scope for this MVP pass:**
- No live claims-stream ingestion API/socket — this is replaced by manual + continuous file-based ingestion.
- No frontend implementation yet — folder placeholder only; pages/UX to be specified later by the user.
- No CI/CD pipeline, no cloud deployment, no container registry push — infra planning only, documented for later phases.
- No production secrets, no real Mistral API key committed anywhere (use `.env`, gitignored).
- Gemini is fully replaced by Mistral throughout — no dual-LLM support needed.
- No second dataset (outpatient, carrier, DME, etc.) — single-file scope only for now.

---

## 5. High-level task breakdown (build order)

**Phase 0 — Environment & repo (this session's output)**
Repo structure, Docker Compose (backend + Postgres), `.env.example`, `requirements.txt`, `data/` folder convention, `inpatient.csv` placed under `data/raw/`.

**Phase 1 — Data engineering foundation**
1.1 Full data profiling of `inpatient.csv` (row/col counts, dtypes, missingness, cardinality, duplicates, numeric/categorical distributions, date columns) → written report.
1.2 Column categorization (identifiers / dates / numerical / categorical / diagnosis-procedure codes) confirmed against the real columns above.
1.3 Sampling strategy for fast local iteration (keep raw file intact under `data/raw/`, generate a working sample under `data/sampled/`).

**Phase 2 — Cleaning & standardization**
Schema validation → dtype conversion → missing-value handling → duplicate detection → invalid-value detection → date standardization (`DD-Mon-YYYY` → ISO). Preserve `original_value` / `cleaned_value` / `quality_issue` for every correction.

**Phase 3 — Great Expectations quality layer**
Define expectation suites per column category (completeness, uniqueness on `CLM_ID`, validity of amounts ≥ 0, dtype checks, range checks, valid code-set checks, date validity, freshness). Compute the 0–100 composite quality score from real check results.

**Phase 4 — Historical baseline**
Compute baseline statistics (claim volume per window, amount mean/median/std/percentiles, missingness rates, duplicate rate, status distribution, processing-time distribution) from the cleaned historical data — all real, computed values.

**Phase 5 — Feature engineering**
Claim-level features (amount ratios, processing duration, date-derived features, encoded categoricals, provider frequency) and window-level features (claim count, amount stats, missingness %, duplicate %, invalid-status %, processing-time stats, volume/amount deviation vs baseline, anomaly count per window).

**Phase 6 — Feature selection**
Stage 1 (drop constant/near-constant/duplicate/raw-ID/high-missingness/leakage columns — several already identified above), Stage 2 (correlation, mutual information, variance, cardinality, missingness thresholds), Stage 3 (XGBoost importance, permutation importance, RFE if needed).

**Phase 7 — Anomaly detection benchmark**
Implement IQR baseline, HBOS, Isolation Forest, LOF. Build an anomaly-injection harness (missing-value spike, amount spike, duplicate spike, volume drop, distribution shift) since the data has no ground-truth anomaly labels. Evaluate precision/recall/F1/FPR/latency/runtime. Select production model empirically (expected HBOS, but only if the benchmark confirms it).

**Phase 8 — Risk dataset construction**
Build incident/window-grain rows (GX failure count, anomaly score, affected-claim %, volume deviation, avg processing delay, historical SLA rate, anomaly frequency, claim count). Define and document the SLA-breach label derivation logic explicitly (this dataset has no pre-existing label — it must be engineered transparently from operational proxies, not invented arbitrarily).

**Phase 9 — Risk model benchmark**
Logistic Regression (baseline) vs Random Forest vs XGBoost. Temporal 70/15/15 train/val/test split (no random shuffling — this is time-dependent data spanning 2015–2022). Evaluate accuracy/precision/recall/F1/ROC-AUC/PR-AUC/calibration/false-negative rate, prioritizing recall + PR-AUC. Select production model empirically.

**Phase 10 — Risk scoring**
Combine Quality Score + Anomaly Score + Operational metrics + Risk Score into Final Incident Priority (40% severity / 30% SLA risk / 20% business impact / 10% affected claims, or whatever weighting is validated during build).

**Phase 11 — LLM investigation (Mistral)**
Structured incident → Mistral 2.5-class model → incident summary, likely root cause, evidence, business impact, recommended fix, prevention recommendation. LLM has read-only access to structured evidence; it never executes remediation.

**Phase 12 — Incident management & HITL**
Incident CRUD, accept/reject endpoints, feedback capture on reject, recalculation loop.

**Phase 13 — Remediation engine**
Deterministic handlers only: duplicate flagging, approved imputation, approved status mapping. Anything unhandled → "Manual Action Required." No LLM-invented fixes.

**Phase 14 — Revalidation**
Re-run GX + anomaly + risk on affected claims after remediation; produce before/after comparison; mark incident Resolved or Reopened.

**Phase 15 — Continuous ingestion (not live streaming)**
Support repeated manual uploads / a watched-folder pattern that processes new batches through the same windowing and pipeline logic used for the historical baseline comparison — explicitly not a live socket/stream API.

**Phase 16 — Testing**
Data tests, ML tests (false pos/neg, stability, leakage, drift), LLM tests (unsupported claims, hallucination, "insufficient evidence" requirement), HITL tests (accept/reject loops), ingestion tests (large files, malformed batches, repeated uploads).

**Phase 17 — Audit & history**
Full audit log across every pipeline stage; `/history` and `/baseline` read endpoints.

**Phase 18 — Frontend (deferred)**
Not started. Pages and UX to be specified by the user after backend completion. Placeholder `frontend/` folder only. When built, it gets its own Dockerfile and is added to `docker-compose.yml` as a `frontend` service — same containerized-deployment pattern as the backend, confirmed by the user.

**Phase 19 — Dockerization & local dev**
Backend Dockerfile + Compose (backend + Postgres) for local development — delivered as part of this session's scope. A `frontend` service and Dockerfile are added to the same Compose file once Phase 18 produces real frontend code.

**Phase 20 — CI/CD (deferred)**
GitHub Actions pipeline (lint → unit tests → ML tests → build → scan → push → deploy) — documented, not implemented yet.

**Phase 21 — Cloud deployment (deferred)**
AWS target architecture documented in Section 3; not provisioned.

**Phase 22 — Model monitoring & retraining (deferred)**
Track anomaly/risk model metrics and data drift; human-feedback-driven periodic retraining with a challenger/champion evaluation gate before redeploying.

---

## 6. Final ML stack (target, pending benchmark confirmation)

| Problem | Method | Status |
|---|---|---|
| Data quality | Great Expectations | Deterministic, always on |
| Anomaly baseline | IQR / percentile | Benchmark baseline |
| Anomaly candidate | Isolation Forest | Benchmarked |
| Anomaly candidate | LOF | Benchmarked |
| **Anomaly production** | **HBOS (pending benchmark)** | Selected only if validated on this data |
| Risk baseline | Logistic Regression | Benchmarked |
| Risk candidate | Random Forest | Benchmarked |
| **Risk production** | **XGBoost (pending benchmark)** | Selected only if validated on this data |
| Root cause / recommendation | **Mistral** (replaces Gemini) | Investigation only, no execution |

No model is hard-selected in advance. Selection happens after Phases 7 and 9 run on the real `inpatient.csv`-derived datasets.

---

## 7. Tooling notes for whoever implements this

- Intended implementation approach: spec-driven development (speckit) inside an empty project folder with its own `.venv`.
- **speckit is already vendored into this repo** under `.specify/` — `memory/constitution.md` (PayerGuard-specific principles, already filled in, not a blank template), `templates/` (spec/plan/tasks/checklist templates + the raw `speckit.*` command templates), and `scripts/bash/` (the helper scripts those commands call). This was assembled directly from https://github.com/github/spec-kit because the scaffolding session ran in a sandbox without PyPI/apt access and couldn't run the real `specify` CLI. Before starting feature work, run `bash scripts/bootstrap_speckit.sh` once (needs `uv`/`uvx` and normal internet access) to generate the missing agent-specific layer — Claude Code skills under `.claude/skills/speckit-*/SKILL.md` that back the `/speckit.specify`, `/speckit.plan`, `/speckit.tasks`, `/speckit.implement` etc. slash commands. That script does not touch `.specify/memory/constitution.md`.
- Reference skills/tooling the user wants applied during implementation (fetch and review before use, don't assume behavior):
  - `anthropics/skills` → `frontend-design` (for when frontend work starts)
  - `anthropics/skills` → `web-artifacts-builder` (for when frontend/artifact work starts)
  - `obra/superpowers` (general tooling to pull in during implementation)
  - `massgen/MassGen` (for efficient multi-file/codebase search during implementation)
- Backend language/stack: Python (FastAPI implied by the API design in Section 3), Postgres, Docker Compose for local dev.
- Secrets: `MISTRAL_API_KEY`, `DATABASE_URL` via `.env` (gitignored), never committed.
- Do not hardcode static thresholds, baseline numbers, or scores anywhere in the implementation — every number in Sections 2–6 that looks like a placeholder must instead be computed from the real data at build time. The numbers in Section 2.2 are measured facts about the current `inpatient.csv` and are provided so implementers know what to expect, not values to hardcode into the pipeline.
